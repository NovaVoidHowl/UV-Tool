# Preview cyan emission investigation — 2026-11-19

The verified defect was an inconsistent Standard emission state created by UV Tool. The fallback converter enabled `_EMISSION` whenever it found a stored emission texture or nonblack colour, while leaving the new material's GI flags at `EmissiveIsBlack` (4). Standard validation disables `_EMISSION` for that flag. The initial cyan pattern was visible emission from the mapped `Misc - Fire` texture, not a changed albedo reference.

The minimal fix preserves the source material's GI flags, calls public `MaterialEditor.FixupEmissiveFlag`, and derives `_EMISSION` from the resulting `EmissiveIsBlack` bit before the first renderer assignment. Opaque RenderType is explicitly initialized as well, so subsequent Standard validation does not add an empty tag. No deferred initialization, asset creation, import, refresh loop, persistent material assets, or third-party dependency is used by the fix.

## Live observations

Project: CCK4-CVRF-Nawvaro, Unity 2022.3.58f1, Built-in pipeline. The user supplied the broken, already-instantiated disposable preview. All experiments changed only disposable instances or generated materials; the controlled import targeted an unrelated existing README. Deploying the rebuilt package caused an expected assembly reload and ended the old disposable session; input paths were retained and a fresh preview was instantiated afterward.

| Operation | Observed result |
| --- | --- |
| Read-only material/renderer snapshot and Scene View capture | Original cyan state persisted. |
| Reassign existing cached arrays on `EditorApplication.delayCall` | Cyan state persisted. |
| `ImportAsset("Assets/MagicaCloth2/Readme.txt", ForceUpdate)` on the initially supplied broken preview | Rendering corrected; `_EMISSION` removed on Body, Horns, Furry Head, Human Face and Hair. |
| Re-enable `_EMISSION` on those generated materials | Cyan rendering returned without changing textures or flags. |
| Invoke Unity's `StandardShaderGUI.ValidateMaterial` directly | Same correction, with no import, reload, source edits or third-party callback. |
| Start a fresh session/material cache on `delayCall`, before the fix | New Body material still had `_EMISSION` plus `EmissiveIsBlack`; deferral did not resolve the inconsistent initialization. |
| Fresh session with the fix | Correct rendering immediately, before any corrective import. |
| Validate all eight fixed fallback materials with StandardShaderGUI | Zero serialized changes across all eight materials. |
| Import the unrelated README after the fix | Fixed material state remained unchanged. |

The first comparison retained the same material IDs (Body `-330198`, Horns `-330200`), Standard shader ID `66`, ordered renderer assignments, texture instance IDs and paths, saved material properties, render queues, blend settings and GI flags. The only serialized differences were `_EMISSION` removals from five `m_ValidKeywords` arrays. See [the recorded comparison](Diagnostics/PreviewMaterialComparison.json), including property hashes and slot arrays.

Body's exposed emission colour was approximately `(0.749, 1.236, 2.996)`, and its emission map was `Misc - Fire`. The original Body and Horns materials themselves reported `EmissiveIsBlack`. Having stored HDR emission data is therefore insufficient evidence that it should be active in a Standard fallback. Custom masks, animations and shader-specific emission enablement are not reproduced; the converter now warns about that limitation.

Creation/assignment checks were performed while `isUpdating=false` and `isCompiling=false`. Moving generation to a later Editor callback did not fix the state; explicit flag/keyword normalization did. There is no evidence requiring shader reinitialization or dependency invalidation to correct this defect.

## Event trace

Read-only live event observers were attached before the first corrective README import without creating a script asset or reloading assemblies. No `projectChanged` or assembly-reload event was recorded for that operation. Full `AssetPostprocessor` instrumentation was installed afterward, because compiling it first would have destroyed the supplied broken preview and contaminated the initial experiment.

The compiled trace then recorded this order:

1. Package DLL deployment: diagnostics initialization at 16:08:54 UTC; `afterAssemblyReload` at 16:08:56; `OnPostprocessAllAssets(didDomainReload=true)` for the conversion DLL; postprocess `delayCall` at 16:09:01. This reload was instrumentation deployment, not the original rendering correction.
2. Fresh fixed preview: assignment at 16:09:37, not compiling/updating.
3. Controlled unrelated README import at 16:10:02: explicit before snapshot → `OnPostprocessAllAssets(didDomainReload=false, imported=[README], no deleted/moved assets)` → import-return snapshot. No project-change or reload event was recorded, and the fixed material snapshots stayed unchanged.
4. A later artificial re-enabling of `_EMISSION` on already validated materials remained enabled through another same-asset import. The original corrective import is consequently a reproduction result for that initially supplied state, not a universal rule that every import validates every loaded material.

The asset postprocessor also queues a read-only delayed snapshot. Later same-asset import experiments did not produce that delayed snapshot during the observation window; it must not be assumed to have run merely because it was queued. The trace records actual callback execution rather than assuming event timing.

The debug flag additionally instruments `beforeAssemblyReload`, `projectChanged`, and cleanup for future reproductions. Assembly-reload cleanup removes generated objects as intended.

## Third-party involvement and bounds of the finding

The project contains Poiyomi/Thry postprocessors, plus Shader Graph and other Editor packages. Relevant source was reviewed. For example, `PoiShaderKeywordPostprocessor` queues repair only for imported Thry shaders; a README does not enter that path. Section-lock and material-repair watchers filter material/shader paths. Built-in Shader Graph's material upgrader filters `.mat` imports.

As an isolation control, all 15 discovered Poiyomi/Thry `OnPostprocessAllAssets` callbacks were invoked individually with the unrelated README path. The five intentionally re-enabled generated-material emission keywords remained enabled after every callback and after subsequent observation. Their synchronous paths did not perform the correction in that experiment. No third-party code was disabled, edited, or blamed.

A clean validation-project headless experiment with a newly constructed inconsistent Standard material and unrelated YAML import did **not** remove `_EMISSION` (one exploratory assertion failed). This result was retained as a limitation, not treated as proof of universal import validation. The final regression instead tests the verified behavior: direct Standard validation normalizes the legacy inconsistent state without any third-party tools, and the corrected converter produces a state that subsequent validation/imports leave unchanged.

The supported mechanism is that a later Editor validation path normalizes the originally inconsistent keyword. The exact native/UI dispatch responsible for validation during the first successful import was not intercepted, so necessity of every installed callback or a specific native import phase is not established. This is not evidence of Poiyomi corruption, stale shader variants or a shader-cache bug. Script creation/domain reload is unnecessary for correction, as demonstrated by direct validation and the initial non-script import.

## Verification and artifacts

All four DLLs compiled with zero warnings/errors. All **68 Edit Mode tests passed**, with zero failures/skips, in Unity 2022.3.58f1. Emission tests cover disabled HDR emission with a texture, enabled Standard/custom-compatible emission, baked-black normalization, source non-mutation, exact serialized stability under Standard validation, and stability across an unrelated import. Existing visibility, caching, cleanup and prefab/mesh safety tests remain passing.

Screenshots and the full development trace are retained locally in the avatar project's `Library/UVPreviewInvestigation/` and `Library/UVTool/PreviewMaterialTrace.log`. The initial live snapshots are also retained at `/tmp/uv-preview-live.txt`; the portable comparison is linked above. The Editor reported stale-inspector null-object exceptions after destroying old preview objects during reload/restarts; no compilation errors or UV Tool stack frames were present in those exceptions. They were not used as evidence for the rendering cause.

The fixed fresh preview was left active, with development tracing disabled after investigation. Source materials, prefab assets and converted meshes were not edited by the fix or diagnostic instrumentation.

## Reference implementation checked

Unity 2022.3's [StandardShaderGUI](https://github.com/Unity-Technologies/UnityCsReference/blob/2022.3/Editor/Mono/Inspector/StandardShaderGUI.cs) derives the emission keyword from the GI flags after calling `FixupEmissiveFlag`. [MaterialEditor](https://github.com/Unity-Technologies/UnityCsReference/blob/2022.3/Editor/Mono/Inspector/MaterialEditor.cs) preserves an explicit `EmissiveIsBlack` state in that fixup. The implementation above uses the public fixup API and the same flag rule; production code does not reflect into internal StandardShaderGUI.
